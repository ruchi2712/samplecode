var app = angular.module('Myapp', ['ngRoute', 'ngCookies', 'ui.bootstrap', 'nvd3']);

app.config(function($routeProvider) {
    $routeProvider
        .when('/', {
            templateUrl: 'views/home.html',
            controller: 'HomeController'
        })
		.when('/home', {
            templateUrl: 'views/home.html',
            controller: 'HomeController'
        })
        .when('/dashboard', {
            templateUrl: 'views/dashboard.html',
            controller: 'DashboardController'
        })
		.when('/employee', {
            templateUrl: 'views/employee/list.html',
            controller: 'EmployeeController'
        })
		.when('/employee/add', {
            templateUrl: 'views/employee/add.html',
            controller: 'EmployeeController'
        })
		.when('/employee/edit/:id', {
            templateUrl: 'views/employee/add.html',
            controller: 'EmployeeController'
        })
		.when('/project', {
            templateUrl: 'views/project.html',
            controller: 'ProjectController'
        })
        .when('/login', {
            templateUrl: 'views/login.html',
            controller: 'LoginController'
        })
        .otherwise({
            redirectTo: '/login'
        });
});
app.run(['$rootScope', '$location', '$cookieStore', '$http',
    function($rootScope, $location, $cookieStore, $http) {
        // keep user logged in after page refresh
        $rootScope.globals = $cookieStore.get('globals') || {};

        $rootScope.$on('$locationChangeStart', function(event, next, current) {
			// Redirect to login page if not logged in
            if (!$rootScope.globals.currentUser && $location.path() !== '/login') {
                $location.path('/login');
            } 
			else if ($location.path() == '/') 
			{
				console.log('Role: '+$rootScope.globals.currentUser.role);
				if($rootScope.globals.currentUser.role == "AM") {
					$location.path('/dashboard');
				} else {
					$location.path('/home');
				}
            } 
        });
    }
]);