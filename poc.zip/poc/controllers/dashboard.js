'use strict';

app.controller('DashboardController', ['$scope', '$rootScope', '$location', '$modal',
    function($scope, $rootScope, $location, $modal) {
        // reset login status
        // AuthenticationService.ClearCredentials();
        $scope.user = $rootScope.globals.currentUser.username;


        $scope.data1 = {
            series: ['Lean Six Sigma', 'iQMS', 'PI Techniques'],
            data: [{
                x: "Lean Six Sigma",
                y: [20]
            }, {
                x: "iQMS",
                y: [4]
            }, {
                x: "PI Techniques ",
                y: [2]
            }]
        };



        $scope.chartType = 'bar';

        $scope.config1 = {
            labels: false,
            title: "WBT",
            legend: {
                display: false,
                position: 'right'
            },
            colors: ['#7f8c8d'],
            innerRadius: 0,
            click: function(points) {
                //alert(235);
                console.log(points);
                console.log(points.srcElement);
            },
            //lineLegend: 'lineEnd'
        };

        $scope.onClick = function(points, evt) {
            console.log(points[0].value); // 0 -> Series A, 1 -> Series B
        };

        $scope.test = function() {
            // alert("Helloo");
            //$scope.markers = itemProvider.addMarkers();
        }









        $scope.options1 = {
            chart: {
                type: 'discreteBarChart',
                height: 450,
                x: function(d) {
                    return d.label;
                },
                y: function(d) {
                    return d.value;
                },
                showValues: true,
                valueFormat: function(d) {
                    return d3.format(',.2f')(d);
                },
                transitionDuration: 500,
                xAxis: {
                    axisLabel: 'WBT',
                    rotateLabels: -20
                },
                yAxis: {
                    axisLabel: 'Employees',
                    axisLabelDistance: 30
                },
                callback: function() {
                    d3.selectAll(".nv-bar").on('click', function(e) {
                        $scope.$broadcast('barclick', e);
                    });
                }
            }
        };

        $scope.data1 = [{
            values: [{
                "label": "Lean six Sigma",
                "value": 10
            }, {
                "label": "iQMS",
                "value": 18
            }, {
                "label": "PI Techniques",
                "value": 5
            }]
        }]




        var colors = ["#1abc9c", "#16a085", "#2ecc71", "#27ae60", "#e67e22", "#d35400", "#e74c3c", "#c0392b"];

        $scope.options = {
            chart: {
                type: 'pieChart',
                height: 400,
                x: function(d) {
                    return d.key;
                },
                y: function(d) {
                    return d.y;
                },
                color: function(d, i) {
                    return colors[i % colors.length]
                },
                showLabels: false,
                showLegend: true,
                legendClick: false,
                transitionDuration: 500,
                //labelThreshold: 0.01,
                stacked: {
                    dispatch: {
                        tooltipShow: function(e) {
                            console.log('! tooltip SHOW !')
                        },
                        tooltipHide: function(e) {
                            console.log('! tooltip HIDE !')
                        },
                        beforeUpdate: function(e) {
                            console.log('! before UPDATE !')
                        },
                        elementClick: function(e) {
                            alert('clicked');
                        }
                    }
                },
                callback: function() {
                    d3.selectAll(".nv-slice").on('click', function(e) {

                        var modalInstance = $modal.open({
                            backdrop: true,
                            backdropClick: false,
                            dialogFade: true,
                            keyboard: false,
                            templateUrl: 'views/popup.html',
                            controller: [
                                '$scope', '$modalInstance',
                                function($scope, $modalInstance) {
                                    $scope.send = function() {
                                        $modalInstance.close();
                                    };

                                    $scope.cancel = function() {
                                        $modalInstance.dismiss('cancel');
                                    };
                                }
                            ],
                            /*resolve: {
								title: function () {
									return title;
								}	
							}*/
                        });
                    });
                }
            }
        };

        $scope.data = '';

        $scope.configs = {
            visible: true, // default: true
        };


        $scope.$on('barclick', function(angularEvent, data) {

            $scope.title = data.label;
            if (data.label == 'Lean six Sigma') {
                $scope.configs = {
                    visible: true, // default: true
                };

                $scope.data = [{
                    key: "Lean Training(21613) Completed ",
                    y: 4,

                }, {
                    key: "Lean Training - (21613)Pending",
                    y: 1,

                }, {
                    key: "Green Belt - (38021) Completed ",
                    y: 3
                }, {
                    key: "Green Belt - (38021) Pending",
                    y: 3
                }, {
                    key: "DMAIC Methodology - (33146) Completed",
                    y: 1
                }, {
                    key: "DMAIC Methodology - (33146) Pending",
                    y: 4
                }];

            } else if (data.label == 'iQMS') {
                $scope.configs = {
                    visible: true, // default: true
                };

                $scope.data = [{
                    key: "iQMS - (48590) Completed",
                    y: 4,

                }, {
                    key: "iQMS - (48590) Pending",
                    y: 1,

                }, {
                    key: "Awareness Quiz - (26539) Completed",
                    y: 3
                }, {
                    key: "Awareness Quiz - (26539) Pending",
                    y: 3
                }, {
                    key: "Case Study For Team Members - ILT/Virtual ILT - (26717) Completed",
                    y: 1
                }, {
                    key: "Case Study For Team Members - ILT/Virtual ILT - (26717) Pending",
                    y: 4
                }, {
                    key: "Quiz for Team Members - (13299) Completed",
                    y: 4
                }, {
                    key: "Quiz for Team Members - (13299) Pending",
                    y: 1
                }];
            } else {
                $scope.configs = {
                    visible: true, // default: true
                };

                $scope.data = [{
                    key: "Process Improvement (PI) Techniques - (15802) Completed",
                    y: 2,

                }, {
                    key: "Process Improvement (PI) Techniques - (15802) Pending",
                    y: 3,

                }, {
                    key: "Process Improvement (PI) Techniques - Exit Test - (9767) Completed",
                    y: 2
                }, {
                    key: "Process Improvement (PI) Techniques - Exit Test - (9767) Pending",
                    y: 4
                }];

            }
            $scope.$apply();
        });


        //$scope.api.refresh();

        //javascript

        //$scope.data = newData;
        //$scope.$apply();  //sometimes you need to refresh the scope

    }
]);