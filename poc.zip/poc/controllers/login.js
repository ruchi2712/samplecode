'use strict';

app.controller('LoginController', ['$scope', '$rootScope', '$location', '$cookieStore',
    function($scope, $rootScope, $location, $cookieStore) {
        // reset login status
        // AuthenticationService.ClearCredentials();

        $scope.login = function() {
            $scope.dataLoading = true;

            if ($scope.username === '1131896' && $scope.password === '123') {
                //authentication.isAuthenticated = true;
                $rootScope.globals = {
                    currentUser: {
                        username: $scope.username,
                        role: 'AM'
                    }
                };
                $rootScope.$broadcast('userLoggedIn', $rootScope.globals);
                $cookieStore.put('globals', $rootScope.globals);
				$location.path('/');
            } else if ($scope.username === '1078603' && $scope.password === '123') {
                //authentication.isAuthenticated = true;
                $rootScope.globals = {
                    currentUser: {
                        username: $scope.username,
                        role: 'AM'
                    }
                };
                $rootScope.$broadcast('userLoggedIn', $rootScope.globals);
                $cookieStore.put('globals', $rootScope.globals);
				$location.path('/');
            } else {
                $scope.loginError = "Invalid username/password combination";
            }

        };
    }
]);