﻿'use strict';


/*app.controller('HomeCtrl',
    ['$scope', '$rootScope', '$location','$cookieStore',
    function ($scope, $rootScope, $location,$cookieStore) {
        // reset login status
        // AuthenticationService.ClearCredentials();

    }]);
*/


app.controller('MainCtrl', ['$scope', '$rootScope', '$location', '$cookieStore',
    function($scope, $rootScope, $location, $cookieStore) {
        $rootScope.globals = $cookieStore.get('globals') || {};
        // reset login status
        // AuthenticationService.ClearCredentials();
        $scope.showheader = false;

        $rootScope.$on('userLoggedIn', function(params) {
            console.log(params); //value
            $scope.showheader = true;

            if ($rootScope.globals.currentUser) {
                $scope.user = $rootScope.globals.currentUser.username;
                $scope.role = $rootScope.globals.currentUser.role;
            }
            //$scope.apply();
        });

        if ($rootScope.globals.currentUser) {
            $scope.showheader = true;
            $scope.user = $rootScope.globals.currentUser.username;
            $scope.role = $rootScope.globals.currentUser.role;
        }
		
		$scope.isActivePath = function (path) {
			if(path == '/') {
				return ($location.path() === path) ? true : false;
			} else {
				return ($location.path().substr(0, path.length) === path) ? true : false;
			}
		}

        $scope.logout = function() {
            $scope.showheader = false;

            $rootScope.globals = {};
            $cookieStore.remove('globals');
            $location.path('/login');
            //$scope.apply();
        }

		/*
        $scope.home = function() {
            if ($rootScope.globals.currentUser.role == "AM") {
                $location.path('/dashboard');
            } else {
                $location.path('/');
            }
        }
		*/




    }
]);