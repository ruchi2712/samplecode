'use strict';

app.controller('EmployeeController', function($scope, $rootScope, $location, $cookieStore, $http, $routeParams) {
		$scope.user = $rootScope.globals.currentUser.username;
		$scope.arrEmployee = [];
		$scope.EmpID = null;
		
		$scope.initList = function() {
            var url = 'DATA/employees.txt';
            $http.get(url).success(function(response) {
                $scope.arrEmployee = response; //JSON.parse(JSON.stringify(response));
                console.log($scope.arrEmployee);
            });
        }
		
		$scope.initEdit = function () {
			$scope.EmpID = $routeParams.id;
			console.log($scope.EmpID);
		}
		
		$scope.add = function() {
			$location.path('/employee/add');
		}
		
		$scope.edit = function(id) {
			$location.path('/employee/edit/'+id);
		}
		
    }
);