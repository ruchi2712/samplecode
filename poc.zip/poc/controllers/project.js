'use strict';

app.controller('ProjectController', ['$scope', '$rootScope', '$location', '$cookieStore',
    function($scope, $rootScope, $location, $cookieStore) {
        // reset login status
        // AuthenticationService.ClearCredentials();
        $scope.user = $rootScope.globals.currentUser.username;

		$scope.dateOptions = {
            formatYear: 'yy',
            startingDay: 0
        };
		
        $scope.formats = ['yyyy-MM-dd', 'dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
        $scope.dateFormat = $scope.formats[0];
		
		
    }
]);