'use strict';

app.controller('HomeController', ['$scope', '$rootScope', '$location', '$cookieStore',
    function($scope, $rootScope, $location, $cookieStore) {
        // reset login status
        // AuthenticationService.ClearCredentials();
        $scope.user = $rootScope.globals.currentUser.username;


        $scope.open = function($event) {
            $event.preventDefault();
            $event.stopPropagation();

            $scope.opened = true;
        };

        $scope.dateOptions = {
            formatYear: 'yy',
            startingDay: 0
        };

        $scope.formats = ['yyyy-MM-dd', 'dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
        $scope.format = $scope.formats[0];
    }
]);